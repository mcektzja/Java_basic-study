package interfacePractice;

public interface Action {
	void work();
	
}

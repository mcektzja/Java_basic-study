//인터페이스 공부 03_
//: ActionExample 클래스의 main() 메소드에서 action의 익명 구현 객체를 만들어
//  다음과 같은 실행 결과가 나올 수 있도록 박스안에 들어갈 코드를 작성해보세요

//  Action action = [ 박스 ] 
//  action.work();
//  <실행결과> 복사를 합니다. 출력
//출처: 이것이 자바다(2022) 8장 확인문제

package interfacePractice;

public class ActionExample {

	public static void main(String[] args) {
		
		Action action = new Action() {    //익명 구현 개체 생성

			@Override
			public void work() {
				System.out.println("복사를 합니다.");
			}
				
		};		
		action.work();

	}

}

//인터페이스 공부 01_
//출처: 이것이 자바다(2022) 8장 확인문제

package interfacePractice;

public class SoundableExample {
	
	private static void printSound(Soundable soundable) {
		System.out.println(soundable.sound());
	}
	
	public static void main(String[]arg) {
		printSound(new Cat());
		printSound(new Dog());
	}
}

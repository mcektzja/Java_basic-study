//인터페이스 공부 01_
//출처: 이것이 자바다(2022) 8장 확인문제

package interfacePractice;

public class Dog implements Soundable{

	@Override
	public String sound() {
		return "멍멍";
	}
}

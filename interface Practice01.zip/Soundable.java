//인터페이스 공부 01_
//출처: 이것이 자바다(2022) 8장 확인문제


package interfacePractice;

public interface Soundable {

	String sound();     //추상메소드
}

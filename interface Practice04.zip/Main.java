//인터페이스 공부 06_ 익명객체 
//출처: 이것이 자바다(2022) 9장

package interfacePractice;

public class Main {

	public static void main(String[] args) {
		Window w = new Window();
		w.button1.touch();
		w.button2.touch();

	}

}

//인터페이스 공부 06_ 익명객체
//출처: 이것이 자바다(2022) 9장

package interfacePractice;

public class Window {
	Button button1 = new Button();   //필드
	Button button2 = new Button();
	
	//필드로 선언
	Button.OnClickListener listener = new Button.OnClickListener() {
		@Override
		public void onClick() {
			System.out.println("전화를 겁니다");
		}
	};
	
	Window(){						//생성자
		button1.setOnClickListener(listener);
		
		 //매개변수에 직접 익명구현객체 대입
		button2.setOnClickListener(new Button.OnClickListener() { 
			@Override
			public void onClick() {
				System.out.println("메세지를 보냅니다");
				
			}
		});
	}
	

	
	
}

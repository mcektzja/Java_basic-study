//인터페이스 공부 06_ 익명객체 
//출처: 이것이 자바다(2022) 9장

package interfacePractice;

public class Button {
	OnClickListener listener;  //필드
	
	void setOnClickListener(OnClickListener listener) {   //인터페이스타입 매개변수
		this.listener = listener;   
	}
	
	void touch() {
		listener.onClick();
	}
	
	interface OnClickListener{
		void onClick();
	}
}

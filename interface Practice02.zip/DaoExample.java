//인터페이스 공부 02_
//: DaoExample 클래스의 main() 메소드에서 dbWork() 메소드를 호출할 때 OracleDao와 
//  MySqlDao 객체를 매개값으로 주고 호출했습니다. dbWork() 메소드는 두 객체를 모두 매개값으로
//  받기 위해 DataAccessObject 타입의 매개변수를 가지고 있습니다. 실행 결과를 보고
//  DataAccessObject 인터페이스와 OracleDao, MySqlDao 구현 클래스를 각각 작성해 보세요.
//  <실행결과> Oracle DB/My Sql DB에서 검색, 삽입, 수정, 삭제 출력
//출처: 이것이 자바다(2022) 8장 확인문제

package interfacePractice;

public class DaoExample {
	
	public static void dbWork(DataAccessObject dao) {  // 다른 두 객체를 DataAccessObject 타입으로 통일
		dao.select();
		dao.insert();
		dao.update();
		dao.delete();
	}

	public static void main(String[] args) {
		dbWork(new OracleDao());                    // 두 객체
		dbWork(new MySqlDao());
		
	}

}

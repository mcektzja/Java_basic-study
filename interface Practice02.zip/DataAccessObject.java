//인터페이스 공부 02_
//출처: 이것이 자바다(2022) 8장 확인문제

package interfacePractice;

public interface DataAccessObject {
	public void select();          // 추상메소드 호출
	public void insert();
	public void update();
	public void delete();
}
